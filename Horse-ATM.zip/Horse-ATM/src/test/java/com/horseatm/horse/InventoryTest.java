package com.horseatm.horse;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.horseatm.horse.inventory.Inventory;
import com.horseatm.horse.model.Denomination;

public class InventoryTest {
	private Inventory inventory;

	@BeforeEach
	public void setUp() {
		final List<Denomination> initialDenominations = new ArrayList<>();

		final Denomination deno1 = new Denomination(1, 10);
		final Denomination deno2 = new Denomination(5, 10);
		final Denomination deno3 = new Denomination(10, 10);
		final Denomination deno4 = new Denomination(20, 10);
		final Denomination deno5 = new Denomination(100, 10);
		initialDenominations.add(deno1);
		initialDenominations.add(deno2);
		initialDenominations.add(deno3);
		initialDenominations.add(deno4);
		initialDenominations.add(deno5);
		inventory = new Inventory(initialDenominations);
	}

	@Test
	public void testCanMakePaymentSufficient() {
		final boolean canMakePayment = inventory.canMakePayment(50);
		assertEquals(true, canMakePayment);
	}

	@Test
	public void testCanMakePaymentInsufficient() {
		final boolean canMakePayment = inventory.canMakePayment(1500);
		assertEquals(false, canMakePayment);
	}

	@Test
	public void testDispenseSufficient() {
		final List<Denomination> list = inventory.dispense(25);

		for (final Denomination denomination : list) {
			if (denomination.getValue() == 20) {
				assertEquals(1, denomination.getCount());
			}
			if (denomination.getValue() == 5) {
				assertEquals(1, denomination.getCount());
			}

		}
	}

}
