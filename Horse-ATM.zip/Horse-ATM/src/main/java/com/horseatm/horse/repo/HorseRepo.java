package com.horseatm.horse.repo;

import java.util.ArrayList;
import java.util.List;

import com.horseatm.horse.model.Horse;

/**
 * @author kapil
 *
 *         Class use for Repository for now its hardcoded but we can plan into
 *         db and save number for dynamic validation and fetch horse details as
 *         well
 *
 */

public class HorseRepo {

	/**
	 *
	 * for the mock object created horse object otherwise we can fetch the horse
	 * object based on horse number from the db
	 */
	enum HorseNumber {
		HORSE_1(1), HORSE_2(2), HORSE_3(3), HORSE_4(4), HORSE_5(5), HORSE_6(6), HORSE_7(7);

		private final int value;

		HorseNumber(final int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
	}

	public boolean isValidHorseNumber(final int horseNumber) {
		for (final HorseNumber number : HorseNumber.values()) {
			if (number.getValue() == horseNumber) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return
	 *
	 *         find horse detail from the db
	 */
	public List<Horse> findAll() {
		final List<Horse> horses = new ArrayList<>();
		final Horse h1 = new Horse(1, "That Darn Gray Cat", 5);
		final Horse h2 = new Horse(2, "Fort Utopia", 10);
		final Horse h3 = new Horse(3, "Count Sheep", 9);
		final Horse h4 = new Horse(4, "Ms Traitour", 4);
		final Horse h5 = new Horse(5, "Real Princess", 3);
		final Horse h6 = new Horse(6, "Pa Kettle", 5);
		final Horse h7 = new Horse(7, "Gin Stinger", 6);

		horses.add(h1);
		horses.add(h2);
		horses.add(h3);
		horses.add(h4);
		horses.add(h5);
		horses.add(h6);
		horses.add(h7);

		return horses;
	}
}
