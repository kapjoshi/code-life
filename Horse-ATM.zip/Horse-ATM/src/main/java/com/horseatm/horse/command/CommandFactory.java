package com.horseatm.horse.command;

/**
 * @author kapil
 *
 *         Command factory use for create method based their input
 *
 */
public class CommandFactory {
	public static Command createCommand(final String commandName) {

		return switch (commandName.toLowerCase()) {
		case "r" -> new ResetInventoryCommand();
		case "q" -> new QuitCommand();
		case "w" -> new SetWinningHorseCommand();
		case "b" -> new PlaceBetCommand();
		default -> new InvalidCommand();
		};

	}
}
