package com.horseatm.horse;

import java.util.List;

import com.horseatm.horse.inventory.Inventory;
import com.horseatm.horse.model.Horse;

/**
 * @author kapil
 *
 *
 *         The HorseRaceATMBase abstract class could be designed to provide a
 *         common structure and basic functionalities that are shared among
 *         different implementations of the HorseRaceATM class. This abstract
 *         class can serve as a foundation that encapsulates common behaviors,
 *         while leaving specific implementation details to its subclasses.
 *
 */
public abstract class HorseRaceATMBase {

	Inventory inventory;
	List<Horse> horses;
	Horse winningHorse;

	public HorseRaceATMBase(final Inventory inventory, final List<Horse> horses) {
		this.inventory = inventory;
		this.horses = horses;
		this.winningHorse = horses.get(0);
	}

	public abstract void processCommand(String command);

	public abstract void displayStatus();

}
