package com.horseatm.horse.repo;

import java.util.ArrayList;
import java.util.List;

import com.horseatm.horse.model.Denomination;

/**
 * @author kapil
 *
 *         Same for the fetch data from the db dynamic configuration
 *
 */
public class DenominationRepo {

	public List<Denomination> findAll() {
		final List<Denomination> initialDenominations = new ArrayList<>();
		final Denomination deno1 = new Denomination(1, 10);
		final Denomination deno2 = new Denomination(5, 10);
		final Denomination deno3 = new Denomination(10, 10);
		final Denomination deno4 = new Denomination(20, 10);
		final Denomination deno5 = new Denomination(100, 10);
		initialDenominations.add(deno1);
		initialDenominations.add(deno2);
		initialDenominations.add(deno3);
		initialDenominations.add(deno4);
		initialDenominations.add(deno5);
		return initialDenominations;
	}
}
