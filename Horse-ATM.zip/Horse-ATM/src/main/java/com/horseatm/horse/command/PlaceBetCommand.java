package com.horseatm.horse.command;

import java.util.List;

import com.horseatm.horse.HorseRaceATM;
import com.horseatm.horse.enumtype.RaceType;
import com.horseatm.horse.exception.HorseATMException;
import com.horseatm.horse.inventory.Inventory;
import com.horseatm.horse.model.Denomination;
import com.horseatm.horse.model.Horse;
import com.horseatm.horse.service.HorseService;

/**
 * @author kapil
 *
 *         The PlaceBetCommand class in your Horse Race ATM simulation serves
 *         the purpose of handling the specific command where a patron places a
 *         bet on a horse
 *
 */
public class PlaceBetCommand implements Command {

	@Override
	public void execute(final HorseRaceATM atm, final String[] commandParts) {
		try {
			final int horseNumber = Integer.parseInt(commandParts[0]);
			final double amount = Double.parseDouble(commandParts[1]);

			final HorseService service = new HorseService();
			if (service.isValidHorse(horseNumber)) {
				placeBet(atm, horseNumber, amount);
			} else {
				throw new HorseATMException("Invalid Horse Number: " + horseNumber);
			}
		} catch (final NumberFormatException e) {
			throw new HorseATMException("Invalid Command Format: " + commandParts);
		}

	}

	/**
	 *
	 * The placeBet method in the PlaceBetCommand class is responsible for handling
	 * the logic related to placing bets on horses
	 *
	 * @param atm
	 * @param horseNumber
	 * @param amount
	 */
	public void placeBet(final HorseRaceATM atm, final int horseNumber, final double amount) {
		if (amount % 1 == 0 && amount > 0) {
			final Horse horse = atm.getHorses().get(horseNumber - 1);
			if (RaceType.WON.equals(horse.getType()) || horse != atm.getWinningHorse()) {
				throw new HorseATMException("No Payout: " + horse.getName());
			} else {
				handleWinningBet(horse, amount, atm.getInventory());
			}
		} else {
			throw new HorseATMException("Invalid Bet: " + amount);
		}
	}

	/**
	 *
	 * The handleWinningBet method is responsible for calculating and handling the
	 * payout for a bet that matches the winning horse.
	 *
	 * @param horse
	 * @param amount
	 * @param inventory
	 */
	private void handleWinningBet(final Horse horse, final double amount, final Inventory inventory) {
		final double winnings = amount * horse.getOdds();
		if (inventory.canMakePayment((int) winnings)) {
			final List<Denomination> inventoryDispense = inventory.dispense((int) winnings);
			System.out.println("Payout: " + horse.getName() + ", $" + String.format("%.2f", winnings));
			System.out.println("Dispensing:");
			inventoryDispense.forEach(list -> System.out.println("$" + list.getValue() + "," + list.getCount()));
			horse.setType(RaceType.WON);
		} else {
			throw new HorseATMException("Insufficient Funds for Payout: $" + String.format("%.2f", winnings));
		}
	}

}
