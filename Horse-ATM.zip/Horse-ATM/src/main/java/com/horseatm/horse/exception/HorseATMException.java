package com.horseatm.horse.exception;

public class HorseATMException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public HorseATMException(final String errorMessage) {
		super(errorMessage);
	}
}
