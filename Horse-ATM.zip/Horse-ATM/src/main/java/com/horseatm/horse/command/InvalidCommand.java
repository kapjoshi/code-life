package com.horseatm.horse.command;

import com.horseatm.horse.HorseRaceATM;
import com.horseatm.horse.exception.HorseATMException;

/**
 * @author kapil
 *
 *         The InvalidCommand class in your Horse Race ATM simulation serves as
 *         a fallback command that handles any input that doesn't match
 *         recognized command patterns
 *
 */
public class InvalidCommand implements Command {
	@Override
	public void execute(final HorseRaceATM atm, final String[] commandParts) {
		throw new HorseATMException("Invalid Command: " + String.join(" ", commandParts));
	}
}
