package com.horseatm.horse.enumtype;

public enum RaceType {
	WON, LOST;
}
