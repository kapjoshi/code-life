package com.horseatm.horse.inventory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.horseatm.horse.model.Denomination;

/**
 * @author kapil
 *
 *         The Inventory class is responsible for managing the inventory of
 *         bills in the Horse Race ATM. It keeps track of the quantity of each
 *         denomination of bills available.
 *
 */
public class Inventory {

	private final List<Denomination> denominations;

	public Inventory(final List<Denomination> initialDenominations) {
		this.denominations = initialDenominations;
	}

	/**
	 * @param amount
	 * @return
	 *
	 *         The canMakePayment method is used to check if the ATM's inventory has
	 *         sufficient bills to make a payment of a certain amount. This method
	 *         is typically used before proceeding with a transaction to ensure that
	 *         the ATM can fulfill the payment request without running out of bills.
	 */
	public boolean canMakePayment(final int amount) {
		int total = 0;
		for (final Denomination denomination : denominations) {
			total += denomination.getValue() * denomination.getCount();
		}
		return total >= amount;
	}

	/**
	 * @param amount
	 * @return
	 *
	 *         The dispense method is used to handle the actual dispensing of bills
	 *         from the ATM's inventory based on a given amount. This method
	 *         calculates the quantity of bills needed for each denomination to meet
	 *         the required amount and updates the inventory accordingly.
	 */
	public List<Denomination> dispense(int amount) {
		Denomination den;
		final List<Denomination> denList = new ArrayList<>();
		Collections.reverse(denominations);
		for (final Denomination denomination : denominations) {
			final int numBills = Math.min(amount / denomination.getValue(), denomination.getCount());
			if (numBills > 0) {
				denomination.decrementCount(numBills);
				den = new Denomination(denomination.getValue(), numBills);
				denList.add(den);
				amount -= numBills * denomination.getValue();
			} else {
				den = new Denomination(denomination.getValue(), 0);
				denList.add(den);
			}
		}
		return denList;

	}

	public void resetInventory() {
		for (final Denomination denomination : denominations) {
			denomination.resetCount();
		}
	}

	public List<Denomination> getDenominations() {
		return denominations;
	}

}
