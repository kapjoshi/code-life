package com.horseatm.horse;

import java.util.List;
import java.util.Scanner;

import com.horseatm.horse.inventory.Inventory;
import com.horseatm.horse.model.Denomination;
import com.horseatm.horse.model.Horse;
import com.horseatm.horse.service.DenominationService;
import com.horseatm.horse.service.HorseService;

public class HorseRaceAtmMain {

	public static void main(final String[] args) {

		final List<Denomination> initalDenominations = new DenominationService().findAll();

		final Inventory inventory = new Inventory(initalDenominations);

		final List<Horse> horses = new HorseService().findAll();

		final HorseRaceATMBase atm = new HorseRaceATM(inventory, horses);

		System.out.println("Welcome to Horse Race Park ATM!");
		atm.displayStatus();

		final Scanner scanner = new Scanner(System.in);

		while (true) {
			final String command = scanner.nextLine().trim();
			atm.processCommand(command);
			atm.displayStatus();
		}

	}

}
