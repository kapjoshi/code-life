package com.horseatm.horse.model;

import com.horseatm.horse.enumtype.RaceType;

public class Horse {
	private final int number;
	private final String name;
	private final int odds;
	private RaceType type;

	public Horse(final int number, final String name, final int odds) {
		this.number = number;
		this.name = name;
		this.odds = odds;
		this.type = RaceType.LOST;
	}

	public int getNumber() {
		return number;
	}

	public String getName() {
		return name;
	}

	public int getOdds() {
		return odds;
	}

	public RaceType getType() {
		return type;
	}

	public void setType(final RaceType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return number + "," + name + ", " + odds + ", " + type;
	}

}
