package com.horseatm.horse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.horseatm.horse.command.Command;
import com.horseatm.horse.command.CommandFactory;
import com.horseatm.horse.command.InvalidCommand;
import com.horseatm.horse.inventory.Inventory;
import com.horseatm.horse.model.Horse;

public class HorseRaceATM extends HorseRaceATMBase {

	private Map<String, Command> commandMap;

	/**
	 * To make the initializeCommands method more generalized and not hardcode the
	 * command mappings, you can use a Map to associate command strings with their
	 * respective Command implementations. This allows you to dynamically add or
	 * remove commands without modifying the initialization method
	 */
	private void initializeCommands() {
		commandMap = new HashMap<>();
		commandMap.put("r", CommandFactory.createCommand("r"));
		commandMap.put("q", CommandFactory.createCommand("q"));
		commandMap.put("w", CommandFactory.createCommand("w"));
		commandMap.put("b", CommandFactory.createCommand("b"));
	}

	/**
	 * @param inventory
	 * @param horses
	 *
	 *
	 *            The constructor HorseRaceATM() initializes the horses, inventory,
	 *            and command map. It also sets the initial winning horse number.
	 */
	public HorseRaceATM(final Inventory inventory, final List<Horse> horses) {
		super(inventory, horses);
		initializeCommands();
	}

	/**
	 * processes user input and delegates command execution based on the provided
	 * command name
	 */
	@Override
	public void processCommand(final String command) {
		try {
			final String[] commandParts = command.trim().split(" ");
			if (commandParts.length == 0) {
				return;
			}

			String cmdPart = commandParts[0].toLowerCase();

			if (commandParts.length == 2 && Character.isDigit(commandParts[0].charAt(0))) {
				cmdPart = "b";
			}

			final Command cmd = commandMap.getOrDefault(cmdPart, new InvalidCommand());
			cmd.execute(this, commandParts);

		} catch (final Exception e) {
			System.out.println(e.getMessage());
		}

	}

	/**
	 * displays the status of the inventory and horses
	 */
	@Override
	public void displayStatus() {
		System.out.println("Inventory:");

		inventory.getDenominations().forEach(System.out::println);

		System.out.println("Horses:");
		horses.forEach(System.out::println);

	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(final Inventory inventory) {
		this.inventory = inventory;
	}

	public List<Horse> getHorses() {
		return horses;
	}

	public void setHorses(final List<Horse> horses) {
		this.horses = horses;
	}

	public Horse getWinningHorse() {
		return winningHorse;
	}

	public void setWinningHorse(final Horse winningHorse) {
		this.winningHorse = winningHorse;
	}

}
