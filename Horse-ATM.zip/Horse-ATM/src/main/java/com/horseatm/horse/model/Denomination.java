package com.horseatm.horse.model;

public class Denomination {
	private final int value;
	private int count;
	private final int initialCount;

	public Denomination(final int value, final int count) {
		this.value = value;
		this.count = count;
		this.initialCount = count;
	}

	public int getValue() {
		return value;
	}

	public int getCount() {
		return count;
	}

	public void decrementCount(final int numBills) {
		count -= numBills;
	}

	public void resetCount() {
		count = this.initialCount;
	}

	@Override
	public String toString() {
		return "$" + value + ", " + count;
	}

}
