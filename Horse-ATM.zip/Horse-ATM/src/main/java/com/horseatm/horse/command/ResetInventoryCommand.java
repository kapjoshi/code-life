package com.horseatm.horse.command;

import com.horseatm.horse.HorseRaceATM;
import com.horseatm.horse.inventory.Inventory;

/**
 * @author kapil
 *
 *         The ResetInventoryCommand class is responsible for handling the
 *         command to reset the inventory of the automated teller machine (ATM)
 *         to its initial state. This involves restoring each denomination's
 *         count to the original inventory amount
 *
 */
public class ResetInventoryCommand implements Command {
	@Override
	public void execute(final HorseRaceATM atm, final String[] commandParts) {
		resetInventory(atm.getInventory());
	}

	public void resetInventory(final Inventory inventory) {
		inventory.resetInventory();
	}
}