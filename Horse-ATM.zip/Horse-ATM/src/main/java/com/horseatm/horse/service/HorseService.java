package com.horseatm.horse.service;

import java.util.List;

import com.horseatm.horse.model.Horse;
import com.horseatm.horse.repo.HorseRepo;

/**
 * @author kapil
 *
 *         Create class for Fetch horse detail and operation
 */
public class HorseService {

	private static HorseRepo horseRepo = new HorseRepo();

	public List<Horse> findAll() {
		return horseRepo.findAll();
	}

	public boolean isValidHorse(final int horseNumber) {
		return horseRepo.isValidHorseNumber(horseNumber);
	}

}
