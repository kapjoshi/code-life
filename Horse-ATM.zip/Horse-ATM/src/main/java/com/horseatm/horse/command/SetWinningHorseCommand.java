package com.horseatm.horse.command;

import java.util.List;

import com.horseatm.horse.HorseRaceATM;
import com.horseatm.horse.enumtype.RaceType;
import com.horseatm.horse.model.Horse;

/**
 * @author kapil
 *
 *         The SetWinningHorseCommand class is responsible for handling the
 *         command to set the winning horse number in the Horse Race ATM
 *         simulation. This command allows the park employee to specify which
 *         horse has won the race
 *
 */
public class SetWinningHorseCommand implements Command {
	@Override
	public void execute(final HorseRaceATM atm, final String[] commandParts) {
		final int horseNumber = Integer.parseInt(commandParts[1]);
		setWinningHorse(horseNumber, atm);

	}

	public void setWinningHorse(final int horseNumber, final HorseRaceATM atm) {
		if (horseNumber >= 1 && horseNumber <= 7) {
			final List<Horse> horses = atm.getHorses();
			for (final Horse horse : horses) {
				if (horse.getNumber() == horseNumber) {
					horse.setType(RaceType.WON);
				} else {
					horse.setType(RaceType.LOST);
				}
			}
		}
	}
}
