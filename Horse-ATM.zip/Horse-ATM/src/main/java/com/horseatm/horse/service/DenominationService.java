package com.horseatm.horse.service;

import java.util.List;

import com.horseatm.horse.model.Denomination;
import com.horseatm.horse.repo.DenominationRepo;

public class DenominationService {

	private static DenominationRepo denRepo = new DenominationRepo();

	public List<Denomination> findAll() {
		return denRepo.findAll();
	}

}
