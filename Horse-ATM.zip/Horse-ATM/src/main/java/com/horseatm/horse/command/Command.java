package com.horseatm.horse.command;

import com.horseatm.horse.HorseRaceATM;

/**
 * @author kapil
 *
 * 
 *         Using the Command interface is a common design pattern that
 *         encapsulates a request as an object, allowing for parameterization of
 *         clients with different requests and providing separation of concerns
 *         between the sender and receiver. In the context of your Horse Race
 *         ATM simulation, the Command interface helps you decouple the caller
 *         (HorseRaceATM) from the individual commands and their execution.
 *
 */
public interface Command {
	void execute(HorseRaceATM atm, String[] commandParts);
}
