package com.horseatm.horse.command;

import com.horseatm.horse.HorseRaceATM;

/**
 * @author kapil
 *
 *         The QuitCommand class is responsible for handling the command to quit
 *         or exit the application. When the user enters the quit command, the
 *         program should gracefully terminate.
 *
 */
public class QuitCommand implements Command {
	@Override
	public void execute(final HorseRaceATM atm, final String[] commandParts) {
		System.exit(0);
	}
}